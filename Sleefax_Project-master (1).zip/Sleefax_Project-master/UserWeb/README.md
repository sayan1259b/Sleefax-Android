# UserWeb

HOME PAGE
https://obailkeri.github.io/Sleefax_Project/UserWeb/home.html

LOGIN
https://obailkeri.github.io/Sleefax_Project/UserWeb/login.html

SIGNUP
https://obailkeri.github.io/Sleefax_Project/UserWeb/signup.html

UPLOAD FILES (Step 1)
https://obailkeri.github.io/Sleefax_Project/UserWeb/upload-files.html

PRINT PROPERTIES (Step 2)
https://obailkeri.github.io/Sleefax_Project/UserWeb/print-properties.html

SELECT SHOP (Step 3)
https://obailkeri.github.io/Sleefax_Project/UserWeb/select-shop.html

CHECKOUT (Step 4)
https://obailkeri.github.io/Sleefax_Project/UserWeb/checkout.html

ORDER PLACED
https://obailkeri.github.io/Sleefax_Project/UserWeb/order-placed.html

ORDER DETAILS
https://obailkeri.github.io/Sleefax_Project/UserWeb/order-details.html

LIVE ORDERS
https://obailkeri.github.io/Sleefax_Project/UserWeb/live-orders.html

ORDER HISTORY
https://obailkeri.github.io/Sleefax_Project/UserWeb/order-history.html

SETTINGS
https://obailkeri.github.io/Sleefax_Project/UserWeb/settings.html
