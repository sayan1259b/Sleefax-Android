# ShopkeeperWeb

WELCOME PAGE
https://obailkeri.github.io/Sleefax_Project/ShopkeeperWeb/welcome-page.html

SIGN UP
https://obailkeri.github.io/Sleefax_Project/ShopkeeperWeb/signup.html

LOGIN
https://obailkeri.github.io/Sleefax_Project/ShopkeeperWeb/login.html

LOGOUT
https://obailkeri.github.io/Sleefax_Project/ShopkeeperWeb/logout.html

NEW ORDERS
https://obailkeri.github.io/Sleefax_Project/ShopkeeperWeb/new_orders.html

PENDING PICKUP
https://obailkeri.github.io/Sleefax_Project/ShopkeeperWeb/pending_for_pickup.html

ORDER HISTORY
https://obailkeri.github.io/Sleefax_Project/ShopkeeperWeb/order_history.html

SETTINGS
https://obailkeri.github.io/Sleefax_Project/ShopkeeperWeb/settings.html

ABOUT US
https://obailkeri.github.io/Sleefax_Project/ShopkeeperWeb/about_us.html

CONTACT US
https://obailkeri.github.io/Sleefax_Project/ShopkeeperWeb/contact_us.html
