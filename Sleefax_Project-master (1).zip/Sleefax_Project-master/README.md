# Sleefax_Project

WELCOME PAGE
https://obailkeri.github.io/Sleefax_Project/ShopkeeperWeb/welcome-page.html

# ShopkeeperWeb
https://obailkeri.github.io/Sleefax_Project/ShopkeeperWeb/

# UserWeb
https://obailkeri.github.io/Sleefax_Project/UserWeb/
